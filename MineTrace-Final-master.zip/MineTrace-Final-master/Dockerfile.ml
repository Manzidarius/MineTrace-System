FROM python:3.11-slim
WORKDIR /app
COPY fraud-detection/requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY fraud-detection/main.py .
CMD uvicorn main:app --host 0.0.0.0 --port ${PORT:-8000}
